using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerHealth : MonoBehaviour
{
    public event Action<float> OnHealthPercentChanged = delegate { };
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth = 100f;
    //khai bao am thanh khi va cham
    private Animator anim;
    private AudioSource audioSource;
    public AudioClip deadSound;
    public AudioClip hurtSound;
    private float time;
    //
    private void Awake()
    {
        anim = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
    }
    public void ModifyHealth(int number)//thay doi % suc khoe
    {
        currentHealth += number;
        float currentHealthPercent = currentHealth / maxHealth;//tinh ra %
        //xu ly am thanh moi khi co thay doi ve suc khoe
        if(currentHealth>10)
        {
            //goi am thanh
            SoundManager.Instance.PlaySound(hurtSound);
        }
        //goi su kien
        OnHealthPercentChanged(currentHealthPercent);
    }
    void Start()
    {
        
    }

    // xu ly khi nhan vat chet
    void Update()
    {
        if(currentHealth<=0)
        {
            audioSource.Pause();
            audioSource.clip = deadSound;
            audioSource.loop = false;
            //
            audioSource.Play();
            audioSource.loop = false;
            //
            anim.SetInteger("Death", 1);
            //
            GetComponent<PlayerRunning>().Dead();
            GetComponent<ScoreManager>().Dead();
            time += Time.deltaTime;
        }
        if(time>3f)
        {
            Application.LoadLevel("GameOverScene");
        }
    }
}
