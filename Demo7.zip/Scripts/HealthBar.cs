using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    private void Awake()
    {
        GetComponentInParent<PlayerHealth>().OnHealthPercentChanged += HandleCapNhat;
    }
    private void HandleCapNhat(float per)
    {
        StartCoroutine(NewRunable(per));
    }
    [SerializeField] private Image healthImage;
    [SerializeField] private float timeUpdate = 0.5f;
    private IEnumerator NewRunable(float p)
    {
        float preChang = healthImage.fillAmount;
        float time = 0f;
        while(time<timeUpdate)
        {
            time += Time.deltaTime;
            //cong,tru mau (cho nguoi dung nhin thay)
            healthImage.fillAmount = Mathf.Lerp(preChang, p, time / timeUpdate);
            yield return null;
        }
        healthImage.fillAmount = p;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
