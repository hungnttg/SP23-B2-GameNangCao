using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    [SerializeField] private Text scoreText;
    [SerializeField] private Text levelText;
    //Khai bao cac bien
    public static float score = 0f;//diem ban dau
    private int level = 1;//level1
    private int maxLevel = 10;//max
    private int scoreToNextLevel = 15;//diem chuyen level
    private bool isDead = false;
    //dinh nghia cac ham
    internal void Dead()//chet
    {
        isDead = true;
    }
    //dinh nghia ham tang diem
    public void TangDiem(float s)
    {
        score += s;
    }
    //dinh nghia ham tang level
    void TangLevel()
    {
        if (level == maxLevel) return;
        //dieu chinh he so tang level (gia su dung 2)
        scoreToNextLevel = scoreToNextLevel * 2;
        ++level; //tang level
        //tang toc do
        GetComponent<PlayerRunning>().SetSpeed(level);
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!isDead)//neu nhan vat chua chet
        {
            if(score>scoreToNextLevel)//dieu kien tang level
            {
                TangLevel();
            }
            //cap nhat thong tin
            scoreText.text = "Score: " + ((int)score).ToString();
            levelText.text = "Level: " + level;
        }
    }
}
