using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerCollider : MonoBehaviour
{
    [SerializeField] private Text locationText;
    public AudioClip collectSound;//xu ly am thanh khi va cham
    private bool isHitStone = true;//trang thai va cham voi da
    //ham xu ly va cham
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if(hit.gameObject.tag=="Coin")//neu nhan vat va cham coin
        {
            //xu ly am thanh
            hit.gameObject.GetComponent<Coin>().Dead();//truy nhap ham Dead tu Coin
            //tang diem
        }
        if(hit.gameObject.tag=="Stone")//neu nhan vay va cham voi da
        {
            //tru diem
            StartCoroutine(EnableCollider(hit, 1));//Thread t=new Thread
        }
        //update len text cua phan canvas
        if(hit.gameObject.tag=="MushroomLocation")
        {
            locationText.text = "Mushroom: Location";
        }
        if (hit.gameObject.tag == "StoneLocation")
        {
            locationText.text = "Stone: Location";
        }
        if (hit.gameObject.tag == "HouseLocation")
        {
            locationText.text = "House: Location";
        }
        if (hit.gameObject.tag == "FireLocation")
        {
            locationText.text = "Fire: Location";
        }
        if (hit.gameObject.tag == "Coin")
        {
            locationText.text = "Coin: Location";
        }
    }
    private IEnumerator EnableCollider(ControllerColliderHit hit,float second)
    {
        isHitStone = false;
        yield return new WaitForSeconds(second); //t.sleep(1)
        isHitStone = true;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
