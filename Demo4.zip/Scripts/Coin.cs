using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    private MeshCollider meshCollider;//mat luoi cua coin
    private void Awake()
    {
        meshCollider = GetComponent<MeshCollider>();//anh xa
    }
    void Start()
    {
        
    }

    void Update()
    {
        transform.Rotate(Vector3.right, 1);//coin xoay sang ben phai
    }
    public void Dead()
    {
        Destroy(gameObject);//huy coin
    }
}
