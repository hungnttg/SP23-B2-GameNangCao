using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    Vector3 moveVector;//vecto di chuyen
    private CharacterController controller;//bo dieu khien nhan vat
    private float speed = 4.0f;//toc do di chuyen
    private float gravity = 9.8f;//gia toc trong truong
    private float animationDuration = 3.0f;//thoi gian xu ly animation
    private float verticalVelocity = 0.0f;//van toc ngang
    void Start()
    {
        //anh xa nhan vat vao code
        controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.time<animationDuration)
        {
            //di chuyen nhan vat
            controller.Move(Vector3.forward * speed * Time.deltaTime);
            return;
        }
        moveVector = Vector3.zero;
        if(controller.isGrounded)//neu cham nen
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        //theo truc X: trai phai
        moveVector.x = Input.GetAxisRaw("Horizontal") * speed;
        //theo truc Y: len xuong
        moveVector.y = verticalVelocity;
        //theo truc x: tien, lui
        moveVector.z = speed;
        //tong hop chuyen dong
        controller.Move(moveVector * Time.deltaTime);

    }
    //ham thay doi toc do (tao do kho cho game)
    public void SetSpeed(float modifier)
    {
        speed = 5.0f + modifier;
    }
}
