using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilesManager : MonoBehaviour
{
    public GameObject[] tilesPrefabs;//mang dia hinh
    private Transform player;//nhan vat
    private List<GameObject> activeTiles;//cac dia hinh dang active
    private float spawnZ = 0f;//khoang cach bien doi
    private float tileLength = 44f;//chieu dai dia hinh
    private int tilesOnScreen = 4;//so dia hinh hien thị dong thoi tren man hinh
    //ham tao dia hình sau khi nhan vat di het dia hinh
    private void TaoDiaHinh(int index=-1)
    {
        GameObject gameObject;//khai bao
        if(index==0)//chi so =0 -> thanh phan dau tien cua mang
        {
            gameObject = Instantiate(tilesPrefabs[0]);//dua dia hinh so 0 vao
        }
        else //lay ngau nhien 1 dia hinh o trong mang
        {
            gameObject = Instantiate(tilesPrefabs[Random.Range(1,tilesPrefabs.Length)]);
        }
        //đưa địa hình mới tạo vào game
        gameObject.transform.SetParent(transform);
        //thuc hien bien doi dia hinh
        gameObject.transform.position = Vector3.forward * spawnZ;
        //xac dinh vi tri moi
        spawnZ += tileLength;
        //dua dia hinh vao mang
        activeTiles.Add(gameObject);
    }
    //ham xoa dia hinh
    private void XoaDiaHinh()
    {
        Destroy(activeTiles[0]);//huy
        activeTiles.RemoveAt(0);//xoa trong mang
    }

    void Start()
    {
        //khoi tao cac bien, mang, anh xa nhan vat
        activeTiles = new List<GameObject>();//khoi tao danh sach dia hinh
        player = GameObject.FindGameObjectWithTag("Player").transform;//anh xa
        //su dung vong lap de khoi tao dia hinh
        for(int i=0;i<tilesOnScreen;i++)
        {
            if(i<1)
            {
                TaoDiaHinh(0);
            }
            else
            {
                TaoDiaHinh();
            }
        }
    }

    void Update()
    {
        //tao dia hinh khi nhan vat den va xoa dia hinh khi nhan vat di qua
        //dieu kien tao dia hinh
        if((player.position.z-tileLength)>(spawnZ-tileLength*tilesOnScreen))
        {
            TaoDiaHinh();//tao khi nhan vat　den
            XoaDiaHinh();//xoa khi nhan vat di
        }

    }
}
