using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private float maxHealth = 100;
    [SerializeField] private float currentHealth = 100;
    private Animator anim;
    private float time;
    private AudioSource audioSource;
    public AudioClip deadSound;//khi chet phat ra am thanh
    public AudioClip hurtSound;//khi dau phat ra am thanh
    //dinh nghia delegate: thay doi phan tram suc khoe
    public event Action<float> OnHealthPecentChanged = delegate { };
    private void Awake()
    {
        anim = GetComponent<Animator>();//anh xa nhan vat
        audioSource = GetComponent<AudioSource>();//anh xa am thanh
    }
    public void ModifyHealth(int amount)//ham thay doi suc khoe
    {
        currentHealth += amount;
        float currentHealthPercent = currentHealth / maxHealth;
        if(currentHealth>10)//co the thay 10 bang so khac
        {
            //phat ra am thanh: dau     
        }
        OnHealthPecentChanged(currentHealthPercent);//thay doi tren man hinh tich mau

    }
    void Start()
    {
        
    }

    // Quan ly suc khoe
    void Update()
    {
        if(currentHealth<=0)//xu ly khi nhan vat chet
        {
            //xu ly am thanh
            audioSource.Pause();
            audioSource.clip = deadSound;
            audioSource.loop = false;
            //---
            audioSource.Play();
            audioSource.loop = false;
            //set trang thai chet
            anim.SetInteger("Death", 1);
            GetComponent<PlayerRunning>().Dead();//goi ham chet: nhan vat khong chay
            GetComponent<ScoreManager>().Dead();//goi ham chet: khong cong diem
        }
        if(time>4f)//thoi gian cho de sang level
        {
            Application.LoadLevel("GameOver");
        }
    }
}
